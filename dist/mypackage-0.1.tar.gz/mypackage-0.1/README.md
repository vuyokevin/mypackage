# mypackage
This library was created as an example on how to publish your own python library

# Building this package locally
'python.setup.py sdist'

## Installing this package from Github
'pip install git+ https://github.com/vuyokevin/mypackage'

## Updating this package from Github
'pip install --upgrade git+ https://github.com/vuyokevin/mypackage'
